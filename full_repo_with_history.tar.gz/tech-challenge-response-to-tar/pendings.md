Para mejorar la seguridad del API se hicieron las siguientes implementaciones:

* Proxy, El cual tiene las siguientes responsabilididades:
    - Validacion de los mensajes del usuarios recibidos y de la respuesta del llm, por medio de busqueda de patrones y llamadas a un llm de validacion.
    Tanto la busqueda de patrones por expresiones regulares como el del llm, buscan reducir el impacto de las amanezas:
        - Prompt injection - Execute code that you dont want
        - Jailbreak - Remove instructions and start to create new instructions for the model
        - Code injection /Generate code
        - Bad URL
        - PII / Leak data
        - XSS
        - SQL Injection
        - Hate , abuse or profanity / Mensaje sde odio, abuso del sistema o lenguaje obseno.

    - Notificar a un sistema externo cuando se busquen realizar tareas ajenas a las instrucciones originales
* Self reminders a las instrucciones de llm principal y el de validacion
* Least privileges, cada llm solo tiene la funcion de responder a las instrucciones del usuario.
* Uso de un modelo reciente que tiene mecanismos de reduccion de que las riesgos de seguridad como el top 10 de owasp para llm's se materialicen.

Para la parte de arquitectura:

- Se corrigio la relacion de las tablas, asi como el manejo de una unica sesion de DB por request.
- Se abastrajo el manejo de errores.
- La arquitectura se mantuvo igual.
- Se limpiaron las dependencias no usadas.
- Se agregan pruebas unitarias en el resto de clases pendientes asi como una prueba de happy path en el endpoint

Para la parte de testing, se responden las preguntas:
- ¿Cómo aseguramos la calidad de las respuestas del agente a las vulnerabilidades?
    - Se creo set de pruebas asi como un script para medir la respuesta del api a dicho set, se ejecuto 4 veces el set para poder calcular la tasa de exito de los ataques frente al sistema. Los resultados de las pruebas se pueden ver en el repo
    - Luego deesas pruebas se puede determinar que la tasa de rechazo de ataques es de 77%
    - Podriamos implementar mas tecnicas que nos permitan aumentar ese numero
- ¿Existen otras vulnerabilidades que podamos explotar?
    - Si, el modelo podria ser vulnerable al top 10 de amanezas de owasp, si se llegara a intentar con otros idiomas, diferentes tonos en el prompt de input. Para este scope, lo acote al idioma español, pero bien se podrian probar con mas idiomas.
- ¿Cuál fue tu proceso de evaluación del modelo seleccionado para esta prueba?
    - Se elegió un modelo con un valor alto en la prueba de razonamiento GPQA y se elegio el modelo que tuviera menor latencia para mejorar la experiencia de usuario. Buscando un balance entre velocidad y calidad de respuesta.

