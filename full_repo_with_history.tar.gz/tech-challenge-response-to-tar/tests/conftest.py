import os
import uuid
from datetime import datetime
from typing import Awaitable
from unittest.mock import AsyncMock, MagicMock, Mock

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlmodel import Session, SQLModel, create_engine
from sqlmodel.pool import StaticPool

os.environ["GOOGLE_API_KEY"] = "test"
os.environ["PORT"] = "1000"
os.environ["HOST"] = "test"
os.environ["LOG_LEVEL"] = "test"
os.environ["DB_HOST"] = "test"
os.environ["DB_PORT"] = "test"
os.environ["DB_USER"] = "test"
os.environ["DB_PASSWORD"] = "test"
os.environ["DB_NAME"] = "test"


from app.depends import get_cases
from app.entities import Conversations, Messages
from app.main import app
from app.messages.adapters import Adapters
from app.messages.cases import Cases, CasesInterface
from app.messages.drivers import Drivers
from app.models import MessageModel
from app.proxy.drivers import ProxyDrivers
from app.proxy.policy import Policy
from app.proxy.proxy import Proxy


@pytest.fixture(name="async_engine")
async def async_engine_fixture():
    async_engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    async with async_engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)
    return AsyncSession(async_engine, expire_on_commit=False)


@pytest.fixture(name="cases")
async def cases_fixture(async_engine: AsyncSession) -> CasesInterface:
    main_agent = AsyncMock()
    main_agent.run.return_value = Mock()
    main_agent.run.return_value.output = "Mock main agent response"
    main_agent.run.return_value.new_messages_json.return_value = (
        b'{"data":"Mock main agent response"}'
    )
    proxy_agent = AsyncMock()
    proxy_agent.run.return_value = AsyncMock()
    proxy_agent.run.return_value.output = "allow"
    proxy = Proxy(Policy(ProxyDrivers(proxy_agent)))
    engine = await async_engine
    return Cases(adapters=Adapters(Drivers(engine, main_agent)), proxy=proxy)


@pytest.fixture(name="client")
def client_fixture(cases: CasesInterface) -> TestClient:
    async def get_cases_override() -> CasesInterface:
        cases_override = await cases  # type: ignore
        return cases_override  # type: ignore

    app.dependency_overrides[get_cases] = get_cases_override
    client = TestClient(app)
    yield client
    app.dependency_overrides.clear()


@pytest.fixture
def sample_message() -> Messages:
    """Create a sample Messages entity for testing"""
    return Messages(
        message_id=uuid.uuid4(),
        content="Test message content",
        role="user",
        insert_datetime=datetime.now(),
    )


@pytest.fixture
def sample_conversation() -> Conversations:
    """Create a sample Conversations entity for testing"""
    return Conversations(conversation_id=uuid.uuid4(), insert_datetime=datetime.now())


@pytest.fixture
def sample_message_model() -> MessageModel:
    """Create a sample MessageModel for testing"""
    return MessageModel(conversation_id=uuid.uuid4(), message="Test message")


@pytest.fixture
def sample_message_model_no_conversation() -> MessageModel:
    """Create a sample MessageModel without conversation_id for testing"""
    return MessageModel(
        conversation_id=None, message="Test message without conversation"
    )


@pytest.fixture
def mock_async_engine() -> MagicMock:
    """Create a mock AsyncEngine for testing"""
    return MagicMock(spec=AsyncEngine)


@pytest.fixture
def mock_drivers_interface() -> AsyncMock:
    """Create a mock DriversInterface for testing"""
    mock = AsyncMock()
    mock.insert_message = AsyncMock()
    mock.insert_first_conversation = AsyncMock(return_value=uuid.uuid4())
    mock.get_messages = AsyncMock(return_value=[])
    mock.get_response_from_agent = AsyncMock(return_value="Mock agent response")
    return mock


@pytest.fixture
def mock_adapters_interface() -> AsyncMock:
    """Create a mock AdaptersInterface for testing"""
    mock = AsyncMock()
    mock.insert_message = AsyncMock()
    mock.get_messages = AsyncMock(return_value=[])
    mock.get_history_messages = AsyncMock(return_value=[])
    mock.insert_first_conversation_messages = AsyncMock(return_value=uuid.uuid4())
    mock.get_response_from_agent = AsyncMock(return_value="Mock agent response")
    mock.convert_agent_model_to_response = MagicMock()
    return mock


@pytest.fixture
def mock_proxy_interface() -> AsyncMock:
    """Create a mock ProxyInterface for testing"""
    mock = AsyncMock()
    mock.valid_message = AsyncMock(return_value=True)
    return mock


@pytest.fixture
def sample_model_response() -> str:
    """Create a sample model response for testing"""
    return '[{"parts":[{"content":"un chiste nuevo","timestamp":"2025-09-03T01:43:49.759895Z","part_kind":"user-prompt"}],"instructions":null,"kind":"request"},{"parts":[{"content":"¡Claro que sí, Pancho! Aquí va otro chiste fresco para ti:\\n\\n¿Qué le dice un jardinero a otro?\\n\\n\\"¿Te has dado cuenta de que ya ha habido **Pancho**s árboles que hemos plantado?\\"\\n\\n¡Espero que te guste, Pancho!","part_kind":"text"}],"usage":{"input_tokens":171,"cache_write_tokens":0,"cache_read_tokens":0,"output_tokens":63,"input_audio_tokens":0,"cache_audio_read_tokens":0,"output_audio_tokens":0,"details":{"text_prompt_tokens":171}},"model_name":"gemini-2.5-flash-lite","timestamp":"2025-09-03T01:43:50.635280Z","kind":"response","provider_name":"google-gla","provider_details":{"finish_reason":"STOP"},"provider_response_id":"Vp23aMHrJMGtz7IPp_vayQo"}]'
