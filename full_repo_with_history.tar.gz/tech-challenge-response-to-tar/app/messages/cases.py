import logging
import uuid
from abc import ABC, abstractmethod
from http import HTTPStatus

from fastapi import HTTPException

from app.errors import DatabaseError, ModelExecutionError, NoMessagesFoundError
from app.messages.adapters import AdaptersInterface
from app.models import MessageModel, ResponseModel
from app.proxy.proxy import ProxyInterface

log = logging.getLogger(__name__)


class CasesInterface(ABC):

    @abstractmethod
    async def get_response(self, message: MessageModel) -> ResponseModel:
        raise NotImplementedError


class Cases(CasesInterface):
    def __init__(self, adapters: AdaptersInterface, proxy: ProxyInterface):
        self.adapters = adapters
        self.proxy = proxy

    async def get_response(self, message: MessageModel) -> ResponseModel:
        # if conversation_id is None is first message
        conversation_id = message.conversation_id
        history = []
        # validate message
        if not await self.proxy.valid_message(message.message):
            log.error(f"Message sent by user is not allowed: {message}")
            raise HTTPException(status_code=HTTPStatus.CONFLICT)
        if conversation_id is None:
            # insert first conversation
            conversation_id = await self._handle_first_conversation(message)
        # if not first message, get history from db
        else:
            history = await self._handle_existing_conversation(message, conversation_id)
            log.debug(f"Continuing conversation with id: {conversation_id}")
        # insert agent response to db
        agent_response = await self._handle_agent_response(
            message, conversation_id, history
        )
        # validate agent response
        if not await self.proxy.valid_message(agent_response):
            log.error(f"Agent response not allowed: {agent_response}")
            raise HTTPException(status_code=HTTPStatus.CONFLICT)
        # convert agent response to response model object
        converted_response = self.adapters.convert_agent_model_to_response(
            conversation_id, message, agent_response, history, history_limit=5
        )
        log.debug(f"Agent response now is stored in db")
        return converted_response

    async def _handle_first_conversation(self, message: MessageModel) -> uuid.UUID:
        """Handle first conversation creation with error handling."""
        try:
            conversation_id = await self.adapters.insert_first_conversation_messages(
                message
            )
            log.debug(f"First conversation inserted with id: {conversation_id}")
            return conversation_id
        except DatabaseError as e:
            log.error(f"Database error on inserting first conversation: {e}")
            raise HTTPException(status_code=HTTPStatus.INTERNAL_SERVER_ERROR)

    async def _handle_existing_conversation(
        self, message: MessageModel, conversation_id: uuid.UUID
    ) -> list:
        """Handle existing conversation with error handling."""
        try:
            history = await self.adapters.get_history_messages(conversation_id)
        except NoMessagesFoundError:
            log.debug(f"No messages found for conversation id: {conversation_id}")
            raise HTTPException(
                status_code=HTTPStatus.NOT_FOUND,
                detail="No messages found for this conversation",
            )
        try:
            await self.adapters.insert_message(message, conversation_id)
        except DatabaseError as e:
            log.error(f"Database error on inserting message: {e}")
            raise HTTPException(status_code=HTTPStatus.INTERNAL_SERVER_ERROR)
        return history

    async def _handle_agent_response(
        self, message: MessageModel, conversation_id: uuid.UUID, history: list
    ) -> str:
        """Handle agent response generation with error handling."""
        try:
            agent_response = await self.adapters.get_response_from_agent(
                message, conversation_id, history
            )
        except ModelExecutionError as e:
            log.error(f"Model execution error on getting response from agent: {e}")
            raise HTTPException(status_code=HTTPStatus.INTERNAL_SERVER_ERROR)
        return agent_response
